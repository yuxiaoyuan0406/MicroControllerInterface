/*********
 * File name	:	matrix.h
 * Author		:	Yu Xiaoyuan
 * Version		:	1.0.0
 * Date			:	2018-11-13 10:11:53
 * Description	:	led matrix driver, with a 8-bit buffer
					HC595
 * Function list:	BufferSendData, MatrixInit, Display_figure
**/
#ifndef __MATRIX_H
#define __MATRIX_H

#include "system.h"

// led matrix port
#define		ROW					P0	//�мĴ���

// matrix row operator
#define		ENABLE_ROW(pos)		ROW = ~(1 << pos)
#define		DISABLE_ROW()		ROW = 0xff
#define		TOGGLE_ROW()		ROW = ~ROW

// soft delay
#define		BUFFER_DELAY()		delay(0x03)

// HC595 port
sbit Out	=	P3 ^ 4;		//����������
sbit R_CLK	=	P3 ^ 5;		//���ݲ����������
sbit S_CLK	=	P3 ^ 6;		//����ʱ����

// HC595 buffer function
void BufferSendData(uint8_t SendVal);

// HC595 operator
#define		ENABLE_BUFFER()		\
do{								\
	R_CLK=0;					\
	BUFFER_DELAY();				\
	R_CLK=1;					\
}while(0)

#define 	DISABLE_BUFFER()	\
do{								\
	BufferSendData(0x00);		\
	ENABLE_BUFFER();			\
}while(0)

// initiate
void MatrixInit();

// display
void Display_figure(uint8_t * fig);

#endif	// !__MATRIX_H
