#ifndef __MAIN_H
#define __MAIN_H

#include "system.h"
#include "figure.h"
#include "keyboard.h"
#include "matrix.h"

#endif	// !__MAIN_H
