#include "system.h"
#include "interrupt.h"

int main()
{
	InterruptInit();	// ʱ���жϳ�ʼ��
	while(1)
	{
		;
	}
}
